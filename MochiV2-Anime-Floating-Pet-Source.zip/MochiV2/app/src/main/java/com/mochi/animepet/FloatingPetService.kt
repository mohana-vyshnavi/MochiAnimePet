package com.mochi.animepet

import android.app.Service
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import kotlin.math.abs
import kotlin.math.sin

/** A self-drawn, animated anime kitten. No emoji or network artwork required. */
class FloatingPetService : Service() {
    private lateinit var windowManager: WindowManager
    private var petView: AnimePetView? = null
    private lateinit var params: WindowManager.LayoutParams
    private val handler = Handler(Looper.getMainLooper())
    private var runningRight = true
    private var modeStarted = 0L
    private var happyUntil = 0L
    private var mode = PetMode.IDLE

    private enum class PetMode { IDLE, RUN, SLEEP }

    private val animator = object : Runnable {
        override fun run() {
            val view = petView ?: return
            val now = android.os.SystemClock.uptimeMillis()
            if (now >= happyUntil) {
                if (now - modeStarted > 6500L) {
                    mode = when (mode) {
                        PetMode.IDLE -> PetMode.RUN
                        PetMode.RUN -> PetMode.SLEEP
                        PetMode.SLEEP -> PetMode.IDLE
                    }
                    modeStarted = now
                }
            } else {
                mode = PetMode.IDLE
            }
            view.mode = if (now < happyUntil) PetMode.IDLE.name else mode.name
            view.happy = now < happyUntil
            if (mode == PetMode.RUN && now >= happyUntil) {
                val screenWidth = resources.displayMetrics.widthPixels
                params.x += if (runningRight) 5 else -5
                if (params.x > screenWidth - dp(112)) runningRight = false
                if (params.x < 0) runningRight = true
                try { windowManager.updateViewLayout(view, params) } catch (_: Exception) { }
            }
            view.invalidate()
            handler.postDelayed(this, 45L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val view = AnimePetView(this)
        petView = view
        params = WindowManager.LayoutParams(
            dp(112), dp(132),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(12)
            y = dp(170)
        }

        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        view.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX; downY = event.rawY
                    startX = params.x; startY = params.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (event.rawX - downX).toInt()
                    params.y = startY + (event.rawY - downY).toInt()
                    try { windowManager.updateViewLayout(v, params) } catch (_: Exception) { }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (abs(event.rawX - downX) < dp(8) && abs(event.rawY - downY) < dp(8)) {
                        happyUntil = android.os.SystemClock.uptimeMillis() + 3500L
                        view.happy = true
                        view.invalidate()
                    }
                    true
                }
                else -> true
            }
        }
        windowManager.addView(view, params)
        modeStarted = android.os.SystemClock.uptimeMillis()
        handler.post(animator)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        handler.removeCallbacks(animator)
        petView?.let { if (it.isAttachedToWindow) windowManager.removeView(it) }
        petView = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

private class AnimePetView(context: android.content.Context) : View(context) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var frame = 0f
    var happy = false
    var mode = "IDLE"

    private fun paint(color: Int, style: Paint.Style = Paint.Style.FILL, stroke: Float = 1f): Paint {
        p.color = color; p.style = style; p.strokeWidth = stroke
        p.strokeCap = Paint.Cap.ROUND; p.strokeJoin = Paint.Join.ROUND
        return p
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        frame += 0.12f
        val sx = width / 112f; val sy = height / 132f
        canvas.save(); canvas.scale(sx, sy)
        val bob = if (mode == "SLEEP") 1.5f else sin(frame.toDouble()).toFloat() * if (mode == "RUN") 5f else 2.5f
        val cx = 56f
        // soft pink floating cushion and sparkle accents
        canvas.drawRoundRect(RectF(3f, 5f, 109f, 127f), 35f, 35f, paint(Color.argb(225, 255, 231, 243)))
        canvas.drawCircle(16f, 24f, 3f, paint(Color.WHITE))
        canvas.drawCircle(96f, 34f, 2.5f, paint(Color.WHITE))
        canvas.save(); canvas.translate(0f, bob)

        // swishing tail
        val tail = Path().apply {
            moveTo(79f, 91f)
            cubicTo(105f, 93f + sin(frame.toDouble()).toFloat() * 8f, 100f, 65f, 91f, 73f)
        }
        canvas.drawPath(tail, paint(Color.rgb(245, 166, 35), Paint.Style.STROKE, 9f))
        canvas.drawPath(tail, paint(Color.rgb(255, 199, 75), Paint.Style.STROKE, 5f))

        // little body
        canvas.drawOval(RectF(29f, 76f, 84f, 119f), paint(Color.rgb(255, 190, 48)))
        // animated feet
        val step = if (mode == "RUN") sin(frame.toDouble() * 2).toFloat() * 5f else 0f
        canvas.drawOval(RectF(31f + step, 108f, 52f + step, 122f), paint(Color.rgb(255, 177, 42)))
        canvas.drawOval(RectF(61f - step, 108f, 82f - step, 122f), paint(Color.rgb(255, 177, 42)))

        // ears
        val leftEar = Path().apply { moveTo(25f, 52f); lineTo(19f, 17f); quadTo(18f, 8f, 28f, 14f); quadTo(43f, 23f, 47f, 43f); close() }
        val rightEar = Path().apply { moveTo(65f, 43f); quadTo(70f, 21f, 86f, 13f); quadTo(96f, 8f, 94f, 20f); lineTo(87f, 55f); close() }
        canvas.drawPath(leftEar, paint(Color.rgb(255, 184, 37)))
        canvas.drawPath(rightEar, paint(Color.rgb(255, 184, 37)))
        val innerL = Path().apply { moveTo(27f, 39f); lineTo(25f, 22f); quadTo(34f, 27f, 39f, 42f); close() }
        val innerR = Path().apply { moveTo(74f, 42f); quadTo(80f, 27f, 89f, 22f); lineTo(85f, 42f); close() }
        canvas.drawPath(innerL, paint(Color.rgb(255, 190, 205)))
        canvas.drawPath(innerR, paint(Color.rgb(255, 190, 205)))

        // round anime kitten face
        canvas.drawOval(RectF(17f, 35f, 95f, 101f), paint(Color.rgb(255, 190, 48)))
        // forehead stripes
        for (x in listOf(48f, 56f, 64f)) {
            canvas.drawLine(x, 39f, x + if (x == 56f) 0f else 2f, 49f, paint(Color.rgb(244, 143, 28), Paint.Style.STROKE, 4f))
        }
        // eyes blink periodically; sleepy mode keeps them closed
        val blink = mode == "SLEEP" || (frame % 8f > 7.55f)
        if (blink) {
            canvas.drawArc(RectF(31f, 61f, 46f, 72f), 10f, 160f, false, paint(Color.rgb(55, 35, 30), Paint.Style.STROKE, 3f))
            canvas.drawArc(RectF(66f, 61f, 81f, 72f), 10f, 160f, false, paint(Color.rgb(55, 35, 30), Paint.Style.STROKE, 3f))
        } else {
            canvas.drawOval(RectF(33f, 59f, 44f, 74f), paint(Color.rgb(35, 25, 20)))
            canvas.drawOval(RectF(68f, 59f, 79f, 74f), paint(Color.rgb(35, 25, 20)))
            canvas.drawCircle(37f, 63f, 2.5f, paint(Color.WHITE)); canvas.drawCircle(72f, 63f, 2.5f, paint(Color.WHITE))
        }
        // cheeks
        canvas.drawOval(RectF(23f, 75f, 39f, 83f), paint(Color.argb(150, 255, 105, 145)))
        canvas.drawOval(RectF(73f, 75f, 89f, 83f), paint(Color.argb(150, 255, 105, 145)))
        // nose and expressive smile
        canvas.drawCircle(cx, 77f, 3f, paint(Color.rgb(75, 40, 35)))
        val mouth = Path().apply {
            moveTo(56f, 80f)
            if (happy) { cubicTo(48f, 93f, 43f, 84f, 42f, 82f); moveTo(56f, 80f); cubicTo(64f, 93f, 69f, 84f, 70f, 82f) }
            else { cubicTo(50f, 88f, 45f, 84f, 44f, 82f); moveTo(56f, 80f); cubicTo(62f, 88f, 67f, 84f, 68f, 82f) }
        }
        canvas.drawPath(mouth, paint(Color.rgb(65, 35, 30), Paint.Style.STROKE, 3f))
        // whiskers
        for (yy in listOf(72f, 81f)) {
            canvas.drawLine(21f, yy, 8f, yy - 3f, paint(Color.rgb(160, 130, 105), Paint.Style.STROKE, 1.8f))
            canvas.drawLine(91f, yy, 104f, yy - 3f, paint(Color.rgb(160, 130, 105), Paint.Style.STROKE, 1.8f))
        }
        // happy hearts / sleepy Zs
        if (happy) {
            drawHeart(canvas, 91f, 49f, 5f)
            drawHeart(canvas, 17f, 56f, 3.5f)
        }
        if (mode == "SLEEP") {
            p.textSize = 12f; p.typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.BOLD)
            p.color = Color.rgb(145, 110, 180); canvas.drawText("Z", 88f, 26f, p); canvas.drawText("z", 98f, 17f, p)
        }
        canvas.restore(); canvas.restore()
        postInvalidateDelayed(45L)
    }

    private fun drawHeart(canvas: Canvas, x: Float, y: Float, size: Float) {
        val path = Path().apply {
            moveTo(x, y + size)
            cubicTo(x - size * 2f, y, x - size, y - size, x, y - size * .25f)
            cubicTo(x + size, y - size, x + size * 2f, y, x, y + size)
        }
        canvas.drawPath(path, paint(Color.rgb(255, 92, 150)))
    }
}
