# Mochi Anime Pet – V2.3 Clean Artwork Update

## Included
- Cleaned transparent PNG assets, including removal of detached taupe/brown matte fragments from the wave and surprised poses.
- Fully transparent pixels are normalized to prevent hidden RGB colour bleeding during Android image scaling.
- Floating Mochi supports drag, single-tap happy reaction, and double-tap to open the full app.
- Floating animation cycles through idle, walk, run/play, and sleep states.
- Main pet screen cycles through idle, blink, smile, curious, and walk poses; low energy switches to sleep.
- Existing offline care, games, dress-up, room and floating-pet screens are retained.

## Build
The project is an Android Gradle project. Use the included GitHub Actions workflow instructions supplied with this source ZIP, or run:

```bash
gradle --no-daemon assembleDebug
```

The debug APK is generated at `app/build/outputs/apk/debug/app-debug.apk`.

## Art note
The included nine individual PNGs are the current bundled poses. The larger sample sheet is a style reference; it is not embedded as one flattened image. New frame-by-frame artwork can be added as separate transparent PNGs in `app/src/main/assets` and then mapped in the animation controller.
