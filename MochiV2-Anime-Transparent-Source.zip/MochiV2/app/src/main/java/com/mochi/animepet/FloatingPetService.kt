package com.mochi.animepet

import android.app.Service
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PixelFormat
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import kotlin.math.abs
import kotlin.math.min

/** Transparent, illustrated anime Mochi overlay. All character art is bundled locally. */
class FloatingPetService : Service() {
    private lateinit var windowManager: WindowManager
    private var petView: AnimePetView? = null
    private lateinit var params: WindowManager.LayoutParams
    private val handler = Handler(Looper.getMainLooper())
    private var movingRight = true
    private var modeStarted = 0L
    private var happyUntil = 0L
    private var mode = PetMode.IDLE
    private var runFrame = 0

    private enum class PetMode { IDLE, RUN, SLEEP }

    private val animator = object : Runnable {
        override fun run() {
            val view = petView ?: return
            val now = SystemClock.uptimeMillis()
            if (now >= happyUntil && now - modeStarted > 7200L) {
                mode = when (mode) {
                    PetMode.IDLE -> PetMode.RUN
                    PetMode.RUN -> PetMode.SLEEP
                    PetMode.SLEEP -> PetMode.IDLE
                }
                modeStarted = now
            }

            val isHappy = now < happyUntil
            view.happy = isHappy
            view.facingLeft = !movingRight
            view.pose = when {
                isHappy -> "wave"
                mode == PetMode.RUN -> if ((runFrame++ / 5) % 2 == 0) "run1" else "run2"
                mode == PetMode.SLEEP -> "sleep4"
                else -> when ((now / 1700L) % 4L) {
                    0L -> "idle"
                    1L -> "idle_blink"
                    2L -> "idle_smile"
                    else -> "idle_surprised"
                }
            }

            if (mode == PetMode.RUN && !isHappy) {
                val screenWidth = resources.displayMetrics.widthPixels
                params.x += if (movingRight) 7 else -7
                if (params.x >= screenWidth - params.width) {
                    params.x = screenWidth - params.width
                    movingRight = false
                } else if (params.x <= 0) {
                    params.x = 0
                    movingRight = true
                }
                view.facingLeft = !movingRight
                try { windowManager.updateViewLayout(view, params) } catch (_: Exception) { }
            }
            view.invalidate()
            handler.postDelayed(this, 90L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val view = AnimePetView(this)
        petView = view
        params = WindowManager.LayoutParams(
            dp(166), dp(150),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8)
            y = dp(150)
        }

        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        view.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX; downY = event.rawY
                    startX = params.x; startY = params.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = (startX + event.rawX - downX).toInt()
                    params.y = (startY + event.rawY - downY).toInt()
                    try { windowManager.updateViewLayout(v, params) } catch (_: Exception) { }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (abs(event.rawX - downX) < dp(8) && abs(event.rawY - downY) < dp(8)) {
                        happyUntil = SystemClock.uptimeMillis() + 3000L
                        view.pose = "wave"
                        view.happy = true
                        view.invalidate()
                    }
                    true
                }
                else -> true
            }
        }
        windowManager.addView(view, params)
        modeStarted = SystemClock.uptimeMillis()
        handler.post(animator)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        handler.removeCallbacks(animator)
        petView?.let { if (it.isAttachedToWindow) windowManager.removeView(it) }
        petView = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

private class AnimePetView(context: android.content.Context) : View(context) {
    private val bitmapCache = mutableMapOf<String, Bitmap>()
    private val imagePaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    var pose: String = "idle"
    var happy: Boolean = false
    var facingLeft: Boolean = false

    private fun bitmap(name: String): Bitmap? {
        return bitmapCache[name] ?: try {
            val loaded = context.assets.open("$name.png").use { BitmapFactory.decodeStream(it) }
            if (loaded != null) bitmapCache[name] = loaded
            loaded
        } catch (_: Exception) { null }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val image = bitmap(pose) ?: bitmap("idle") ?: return
        val availableW = width.toFloat()
        val availableH = height.toFloat()
        val scale = min(availableW / image.width, availableH / image.height) * 0.98f
        val drawW = image.width * scale
        val drawH = image.height * scale
        val left = (availableW - drawW) / 2f
        val top = (availableH - drawH) / 2f

        canvas.save()
        if (facingLeft && pose.startsWith("run")) {
            canvas.scale(-1f, 1f, width / 2f, height / 2f)
        }
        // PNG artwork has a transparent alpha channel: no badge, tile or backdrop.
        canvas.drawBitmap(image, null,
            android.graphics.RectF(left, top, left + drawW, top + drawH), imagePaint)
        canvas.restore()
    }
}
