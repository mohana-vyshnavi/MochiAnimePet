# Mochi Anime Pet — V2.1 illustrated companion

This Android project contains the offline Mochi pet app and its transparent anime floating companion.

## Character artwork
- Custom cream-white and orange anime kitten with glossy brown eyes, blush, pink ears and a red collar with a gold bell.
- PNG sprites are stored in `app/src/main/assets/` with transparent alpha backgrounds.
- The app home screen uses the illustrated kitten instead of the earlier SVG cartoon.
- The floating companion uses the same local PNG artwork; no emoji, remote image, or coloured badge background is drawn behind it.

## Floating companion behaviour
- Idle poses cycle through open eyes, blink, smile and surprised expressions.
- The pet moves horizontally in side profile using two running poses, flipping to face its direction of travel.
- Sleep mode shows the curled-up sleeping pose.
- Tapping gives a happy wave; dragging repositions the pet.
- Artwork is bundled locally and works offline.

## Build
Open the project in Android Studio or build from the project root with Gradle 8.9 and Java 17:

```bash
gradle --no-daemon assembleDebug
```

The debug APK is generated at `app/build/outputs/apk/debug/app-debug.apk`.
