# Mochi Anime Pet – V2.2

## V2.2 fixes
- Removed the unwanted taupe/brown matte fragments from the floating character PNGs.
- Preserved transparent PNG backgrounds so the pet sits cleanly over the wallpaper.
- Added double-tap on the floating Mochi to open the full app.
- Single tap still triggers the happy/wave reaction; dragging still moves Mochi.
- Updated the Floating tab instructions.

## Build
Use the repository GitHub Actions workflow to run `gradle assembleDebug`.
The debug APK is generated at `app/build/outputs/apk/debug/app-debug.apk`.

The project is offline-first and bundles its character art in `app/src/main/assets`.
