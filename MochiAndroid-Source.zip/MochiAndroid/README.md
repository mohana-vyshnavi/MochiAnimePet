# Mochi – My Little Anime Pet

A first Android wrapper project for the offline pet-care prototype.

## Included in v1
- Offline WebView app with local HTML/CSS/JavaScript assets
- Mochi pet-care stats: hunger, happiness, energy and cleanliness
- Feed, play, bathe and sleep actions
- Tap-to-pet interaction
- Catch-the-star mini-game and coin rewards
- Local progress saving using browser localStorage
- No ads, analytics or network permission

## Build APK in GitHub Actions (phone-friendly route)
1. Create/sign in to a GitHub account in your phone browser.
2. Create a new empty repository named `MochiAnimePet`.
3. Upload the contents of this project ZIP to the repository root (not the ZIP itself). Keep the `.github/workflows/build-apk.yml` folder and file.
4. Open the repository's **Actions** tab. If prompted, enable workflows.
5. Open **Build Mochi Android APK** and choose **Run workflow**. A push to `main` also starts a build.
6. When the run completes, open it and download the artifact named `Mochi-Anime-Pet-debug-apk`.
7. Extract the artifact ZIP on your phone and install `app-debug.apk`. Android may ask you to allow installation from that browser/file manager.

The APK produced by this workflow is a debug APK for personal testing, not a Play Store release. A release APK should be signed with a private signing key before distribution.

## Local build
Requires JDK 17, Android SDK platform 35/build tools and Gradle 8.9:

```bash
gradle assembleDebug
```

Output: `app/build/outputs/apk/debug/app-debug.apk`.

## Next development steps
The current character uses an emoji placeholder. Replace it with original anime kitten artwork and sprite animations; then add a dedicated Android overlay service for floating mode. The overlay feature is not included in this first build.
