package com.mochi.animepet

import android.app.Service
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PixelFormat
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import kotlin.math.abs
import kotlin.math.min

/** Floating, transparent anime Mochi companion. Artwork is bundled locally. */
class FloatingPetService : Service() {
    private lateinit var windowManager: WindowManager
    private var petView: AnimePetView? = null
    private lateinit var params: WindowManager.LayoutParams
    private val handler = Handler(Looper.getMainLooper())
    private var movingRight = true
    private var modeStarted = 0L
    private var happyUntil = 0L
    private var mode = PetMode.IDLE
    private var lastTapAt = 0L

    private enum class PetMode { IDLE, WALK, RUN, PLAY, SLEEP }

    private val animator = object : Runnable {
        override fun run() {
            val view = petView ?: return
            val now = SystemClock.uptimeMillis()
            val elapsed = now - modeStarted
            val modeDuration = when (mode) {
                PetMode.IDLE -> 10_000L
                PetMode.WALK -> 7_000L
                PetMode.RUN -> 4_000L
                PetMode.PLAY -> 5_000L
                PetMode.SLEEP -> 9_000L
            }
            if (now >= happyUntil && elapsed >= modeDuration) {
                mode = when (mode) {
                    PetMode.IDLE -> PetMode.WALK
                    PetMode.WALK -> PetMode.IDLE
                    PetMode.RUN -> PetMode.PLAY
                    PetMode.PLAY -> PetMode.SLEEP
                    PetMode.SLEEP -> PetMode.IDLE
                }
                modeStarted = now
            }

            val isHappy = now < happyUntil
            view.happy = isHappy
            view.facingLeft = !movingRight
            val phase = now - modeStarted
            view.pose = when {
                isHappy -> "wave"
                mode == PetMode.SLEEP -> "sleep4"
                mode == PetMode.WALK -> when ((phase / 560L) % 3L) {
                    0L -> "walk1"
                    1L -> "run1"
                    else -> "walk1"
                }
                mode == PetMode.RUN || mode == PetMode.PLAY ->
                    if ((phase / if (mode == PetMode.PLAY) 620L else 560L) % 2L == 0L) "run1" else "run2"
                else -> when ((phase / 2_500L) % 4L) {
                    0L -> "idle"
                    1L -> "idle_blink"
                    2L -> "idle_smile"
                    else -> "idle_surprised"
                }
            }

            if (!isHappy && (mode == PetMode.WALK || mode == PetMode.RUN || mode == PetMode.PLAY)) {
                val screenWidth = resources.displayMetrics.widthPixels
                // Gentle walking speed; running is deliberately only a little quicker.
                val stepDp = when (mode) {
                    PetMode.WALK -> 1.0f
                    PetMode.PLAY -> 2.0f
                    else -> 2.5f
                }
                val step = dp(stepDp).coerceAtLeast(1)
                params.x += if (movingRight) step else -step
                if (params.x >= screenWidth - params.width) {
                    params.x = screenWidth - params.width
                    movingRight = false
                } else if (params.x <= 0) {
                    params.x = 0
                    movingRight = true
                }
                view.facingLeft = !movingRight
                try { windowManager.updateViewLayout(view, params) } catch (_: Exception) { }
            }
            view.invalidate()
            handler.postDelayed(this, 100L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val view = AnimePetView(this)
        petView = view
        params = WindowManager.LayoutParams(
            dp(166f), dp(150f),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8f)
            y = dp(150f)
        }

        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        view.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX; downY = event.rawY
                    startX = params.x; startY = params.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = (startX + event.rawX - downX).toInt()
                    params.y = (startY + event.rawY - downY).toInt()
                    try { windowManager.updateViewLayout(v, params) } catch (_: Exception) { }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val wasTap = abs(event.rawX - downX) < dp(8f) &&
                        abs(event.rawY - downY) < dp(8f)
                    if (wasTap) {
                        val tapTime = SystemClock.uptimeMillis()
                        if (tapTime - lastTapAt in 1L..450L) {
                            lastTapAt = 0L
                            val openApp = Intent(this@FloatingPetService, MainActivity::class.java).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                            }
                            try { startActivity(openApp) } catch (_: Exception) { }
                        } else {
                            lastTapAt = tapTime
                            happyUntil = tapTime + 2_600L
                            view.pose = "wave"
                            view.happy = true
                            view.invalidate()
                        }
                    }
                    true
                }
                else -> true
            }
        }
        windowManager.addView(view, params)
        modeStarted = SystemClock.uptimeMillis()
        handler.post(animator)
    }

    private fun dp(value: Float): Int = (value * resources.displayMetrics.density).toInt()
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        handler.removeCallbacks(animator)
        petView?.let { if (it.isAttachedToWindow) windowManager.removeView(it) }
        petView = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}

private class AnimePetView(context: android.content.Context) : View(context) {
    private val bitmapCache = mutableMapOf<String, Bitmap>()
    private val imagePaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG or Paint.DITHER_FLAG)
    var pose: String = "idle"
    var happy: Boolean = false
    var facingLeft: Boolean = false

    private fun bitmap(name: String): Bitmap? = bitmapCache[name] ?: try {
        val loaded = context.assets.open("$name.png").use { BitmapFactory.decodeStream(it) }
        if (loaded != null) bitmapCache[name] = loaded
        loaded
    } catch (_: Exception) { null }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val image = bitmap(pose) ?: bitmap("idle") ?: return
        val scale = min(width.toFloat() / image.width, height.toFloat() / image.height) * 0.96f
        val drawW = image.width * scale
        val drawH = image.height * scale
        val left = (width - drawW) / 2f
        val top = (height - drawH) / 2f
        canvas.save()
        if (facingLeft && (pose.startsWith("run") || pose == "walk1")) {
            canvas.scale(-1f, 1f, width / 2f, height / 2f)
        }
        // No background, glow, shadow, or coloured tile is drawn behind the PNG.
        canvas.drawBitmap(image, null, android.graphics.RectF(left, top, left + drawW, top + drawH), imagePaint)
        canvas.restore()
    }
}
