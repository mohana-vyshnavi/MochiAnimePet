# Mochi – My Little Anime Pet v2.0

An offline-first Android virtual pet game. The Android app hosts a local HTML5 game in a WebView; pet progress is stored locally in WebView localStorage. No analytics, ads, account, or network access is used.

## V2 features
- Custom vector-drawn anime-inspired kitten (SVG; no emoji-only character)
- Care actions: feed, play, bathe, sleep and cuddle
- Hunger, happiness, energy and cleanliness stats with gentle offline decay
- XP and levels, daily gift and coin economy
- Star-catching timed mini-game, memory-match game and bubble-pop reward
- Outfit/accessory shop and room decoration store
- Album badges
- Optional draggable Android floating pet overlay. The user must explicitly grant Android's “Display over other apps” permission. The overlay only displays a small pet bubble; it does not inspect or control other apps.

## Build from GitHub Actions
1. Put `MochiV2-Source.zip` in the root of your GitHub repository.
2. Put this workflow at `.github/workflows/build-apk.yml` (or use the workflow included in this ZIP after extracting the project).
3. Open Actions → Build Mochi APK → Run workflow.
4. Download the `Mochi-V2-APK` artifact, extract it, and install `app-debug.apk`.

Build requirements: JDK 17, Gradle 8.9, Android Gradle Plugin 8.7.3, Android SDK platform 35. The workflow installs/configures the build tools on GitHub-hosted Ubuntu.

## Local project
The Android Studio project is under this folder. App ID: `com.mochi.animepet`, version 2.0, min SDK 23, target SDK 35.
