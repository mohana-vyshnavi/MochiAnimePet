package com.mochi.animepet

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import kotlin.math.abs

class FloatingPetService : Service() {
    private lateinit var windowManager: WindowManager
    private var petView: TextView? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val bubble = TextView(this).apply {
            text = "🐱"
            textSize = 42f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.argb(235, 255, 226, 241))
                setStroke(3, Color.WHITE)
            }
            elevation = 12f
            contentDescription = "Mochi floating pet. Drag to move; tap to cuddle."
        }
        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        val params = WindowManager.LayoutParams(
            88, 88, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 30
            y = 220
        }
        var downX = 0f
        var downY = 0f
        var startX = 0
        var startY = 0
        bubble.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    downX = event.rawX; downY = event.rawY
                    startX = params.x; startY = params.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (event.rawX - downX).toInt()
                    params.y = startY + (event.rawY - downY).toInt()
                    windowManager.updateViewLayout(view, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (abs(event.rawX - downX) < 8 && abs(event.rawY - downY) < 8) {
                        bubble.text = if (bubble.text == "🐱") "😻" else "🐱"
                    }
                    true
                }
                else -> false
            }
        }
        petView = bubble
        windowManager.addView(bubble, params)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        petView?.let { if (it.isAttachedToWindow) windowManager.removeView(it) }
        petView = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
